# For 42KL python piscince

This package is created for 42KL student to excercise using python for the first time.